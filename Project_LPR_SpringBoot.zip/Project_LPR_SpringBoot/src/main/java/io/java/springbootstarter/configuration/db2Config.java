package io.java.springbootstarter.configuration;



import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

//@Configuration
//@EnableTransactionManagement
//@EnableJpaRepositories(
//		entityManagerFactoryRef = "mysqlEntityManager",
//        basePackages = { "io.java.springbootstarter.repository.Topics1" }
//)
//public class db2Config {
//	@Bean
//    @Primary
//    @ConfigurationProperties(prefix = "db2.datasource")
//    public DataSource oraclesqlDataSource() {
//        return DataSourceBuilder
//                    .create()
//                    .build();
//    }
// 
//    @Primary
//    @Bean(name = "oraclesqlEntityManager")
//    public LocalContainerEntityManagerFactoryBean oraclesqlEntityManagerFactory(EntityManagerFactoryBuilder builder) {
//        return builder
//                    .dataSource(oraclesqlDataSource())
//                    .packages("io.java.springbootstarter.model2") // you can also give the package where the Entities are given rather than giving Entity class
//                    .persistenceUnit("Topics2")
//                    .build();
//    }
// 
//    @Primary
//    @Bean(name = "oraclesqlTransactionManager")
//    public PlatformTransactionManager oraclesqlTransactionManager(@Qualifier("oraclesqlEntityManager") EntityManagerFactory entityManagerFactory) {
//        return new JpaTransactionManager(entityManagerFactory);
//    }
//}
//
//





@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
  entityManagerFactoryRef = "entityManagerFactory",
  basePackages = { "io.java.springbootstarter.repository.Topics2" }
)
public class db2Config {
  
  @Primary
  @Bean(name = "dataSource")
  @ConfigurationProperties(prefix = "db2.datasource")
  public DataSource dataSource() {
    return DataSourceBuilder.create().build();
  }
  
  @Primary
  @Bean(name = "entityManagerFactory")
  public LocalContainerEntityManagerFactoryBean 
  entityManagerFactory(
    EntityManagerFactoryBuilder builder,
    @Qualifier("dataSource") DataSource dataSource
  ) {
    return builder
      .dataSource(dataSource)
      .packages("io.java.springbootstarter.model2")
      .persistenceUnit("Topics2")
      .build();
  }
    
  @Primary
  @Bean(name = "transactionManager")
  public PlatformTransactionManager transactionManager(
    @Qualifier("entityManagerFactory") EntityManagerFactory 
    entityManagerFactory
  ) {
    return new JpaTransactionManager(entityManagerFactory);
  }
}
